package channelMergingImageJ1;

public interface ChannelSwapListener {
	
	public void afterChanSwap();

}
