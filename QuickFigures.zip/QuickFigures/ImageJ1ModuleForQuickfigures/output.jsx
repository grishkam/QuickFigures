#target illustrator

var item2948076 = app.documents.add(DocumentColorSpace.RGB,300.0,300.0);
var item6518519 =item2948076.rasterEffectSettings;
item6518519.resolution=300.0;
var item47113829 =item2948076.layers.add();
try{item47113829.name='Figure';} catch (err) {}
var item94731338 =item2948076.rasterEffectSettings;
item94731338.resolution=300.0;
var item52866770 =item47113829.layers.add();
try{item52866770.name='Figure';} catch (err) {}