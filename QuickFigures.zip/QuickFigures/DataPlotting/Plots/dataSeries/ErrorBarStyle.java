package dataSeries;

public interface ErrorBarStyle {
	public static int LineOnly=0, Bar=1;
	
	public static int SD=0, SEM=1, SEM2=2, SEM3=3;;
	
	public static int UPPER_BAR=10, LOWER_BAR=20;
}
