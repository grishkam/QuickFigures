package xyPlots;

import graphicalObjects_BasicShapes.RectangularGraphic;

public class FigureLegendRect  extends RectangularGraphic {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
