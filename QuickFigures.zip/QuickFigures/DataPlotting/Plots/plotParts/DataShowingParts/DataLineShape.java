package plotParts.DataShowingParts;

import utilityClassesForObjects.StrokedItem;

public interface DataLineShape extends StrokedItem {

}
