package plotParts.DataShowingParts;

import java.awt.Rectangle;

public interface SeriesLabelPositionAnchor {

	Rectangle getPlotLabelLocationShape();

}
