package plotParts.Core;

public interface PlotOrientation {
	static int BARS_VERTICAL=0;
	static int BARS_HORIZONTAL=1;;
}
