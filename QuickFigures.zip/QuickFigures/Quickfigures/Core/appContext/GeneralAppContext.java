package appContext;

import java.awt.Color;

public interface GeneralAppContext {
	
	public Color getForeGroundColor() ;

	
	public Color getBackGroundColor() ;
}
