package infoStorage;

import java.io.Serializable;

/**will read channel names from meta data*/
public class channelNameReader implements Serializable {

	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public channelNameReader() {
		// TODO Auto-generated constructor stub
	}


	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
