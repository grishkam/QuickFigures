package figureTemplates;

public class AutoFigureGenerationOptions {
	public boolean addChannelLabels=true;
	public boolean showPanelDialog=true;
	public boolean autoGenerateFromModel=false;
	public boolean onlyFirstSetGetsChannelLabels=true;
	
}
