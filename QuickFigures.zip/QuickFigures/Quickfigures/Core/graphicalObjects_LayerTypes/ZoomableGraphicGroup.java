package graphicalObjects_LayerTypes;

public interface ZoomableGraphicGroup {
	/**gets the internal layer*/
	public GraphicLayer getTheLayer();
}
