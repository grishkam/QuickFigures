package graphicalObjects_LayerTypes;

import java.util.ArrayList;

import graphicalObjects.ZoomableGraphic;

public interface GraphicHolder {
	
	/**returns all the held graphics. experimental*/
	public ArrayList<ZoomableGraphic> getAllHeldGraphics();
}
