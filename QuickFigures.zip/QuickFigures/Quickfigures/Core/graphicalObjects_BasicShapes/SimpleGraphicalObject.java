package graphicalObjects_BasicShapes;

import graphicalObjects.ZoomableGraphic;
import utilityClassesForObjects.LocatedObject2D;
import utilityClassesForObjects.Selectable;

public interface SimpleGraphicalObject extends LocatedObject2D, ZoomableGraphic,Selectable{

}
