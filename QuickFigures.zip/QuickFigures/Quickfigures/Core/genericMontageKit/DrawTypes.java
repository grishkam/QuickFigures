package genericMontageKit;

public interface DrawTypes {
	public static final int PIXELS=0, PHOTOSHOP=2, PHOTOSHOP2=3, OVERLAY=1, ILLUSTRATOR=4;
}
