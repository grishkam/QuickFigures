package genericMontageKit;

public interface PanelLayoutContainer {
	public PanelLayout getPanelLayout();
}
