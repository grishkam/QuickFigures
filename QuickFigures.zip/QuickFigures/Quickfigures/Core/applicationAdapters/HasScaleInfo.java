package applicationAdapters;

import utilityClassesForObjects.ScaleInfo;

public interface HasScaleInfo {
	public ScaleInfo getScaleInfo();
	public void setScaleInfo( ScaleInfo scaleInfo);
}
