package graphicalObjectHandles;

public interface HasSmartHandles {
	public SmartHandleList getSmartHandleList();
	
}
