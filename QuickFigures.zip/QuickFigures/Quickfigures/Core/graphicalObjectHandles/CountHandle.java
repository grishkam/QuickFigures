package graphicalObjectHandles;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import applicationAdapters.CanvasMouseEventWrapper;
import graphicalObjects_BasicShapes.CountParameter;
import undo.SimpleItemUndo;
import utilityClassesForObjects.LocatedObject2D;

public class CountHandle extends SmartHandle {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private LocatedObject2D polygon;
	private CountParameter count;
	int oX = 25;
	int oY = 24;
	private boolean circle=false;
	private double widthStretch=1;


	public CountHandle(LocatedObject2D regularPolygonGraphic, CountParameter number, int handleNumber) {
		super(0,0);
		polygon=regularPolygonGraphic;
		this.count=number;
		this.setHandleNumber(handleNumber);
		message=count.getValueAsString();
		this.handlesize=10;
		
	}
	
	public CountHandle(LocatedObject2D r, CountParameter n, int handle, int dx, int dy, boolean h, double expandWidth) {
		this(r,n, handle);
		oX=dx;
		oY=dy;
		circle=h;
		this.widthStretch=expandWidth;
	}
	
	public int getDrawnHandleWidth() {
		return (int) (handleSize()*2*widthStretch);
	}
	
	public int getDrawnHandleHeight() {
		return handleSize()*2;
	}
	
	public Point2D getCordinateLocation() {
		
		return new Point2D.Double(polygon.getBounds().getMaxX()+oX, polygon.getBounds().getMinY()+oY);
	}
	public void handlePress(CanvasMouseEventWrapper canvasMouseEventWrapper) {
		SimpleItemUndo<CountParameter> undo = new SimpleItemUndo<CountParameter> (count);
		
		double place = this.lastDrawShape.getBounds().getCenterY();
		boolean down=canvasMouseEventWrapper. getClickedYScreen()>place;
		int nV=count.getValue()+(down?-1:1);
		if(nV<count.getMinValue() &&!circle) return;
		
		if(nV<count.getMinValue() &&circle)  count.setValue(count.getMaxValue());
			else
		if (nV>count.getMaxValue()) count.setValue(count.getMinValue());
			else
			count.setValue(nV);
		
		canvasMouseEventWrapper.addUndo(undo);
		
		canvasMouseEventWrapper.getAsDisplay().updateDisplay();
	}
	
	
	protected void drawMessage(Graphics2D graphics, Shape s) {
		
			graphics.setColor(messageColor);
			graphics.setFont(getMessageFont());
			int y2 = (int)(s.getBounds().getCenterY()/2+s.getBounds().getMaxY()/2);
			int x2 = (int)s.getBounds().getX()+4;
			String valueAsString = count.getValueAsString();
			Rectangle2D b = graphics.getFontMetrics().getStringBounds(valueAsString, graphics);
			double end = b.getWidth();
			
			
			graphics.drawString(valueAsString, x2, y2);
		
	}

}