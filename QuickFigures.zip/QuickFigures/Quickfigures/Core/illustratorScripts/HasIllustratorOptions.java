package illustratorScripts;

public interface HasIllustratorOptions {
	
	public void showOptionsForExport();

}
