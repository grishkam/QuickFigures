package illustratorScripts;

public interface IllustratorObjectConvertable {
	Object toIllustrator(ArtLayerRef aref);
	
}
