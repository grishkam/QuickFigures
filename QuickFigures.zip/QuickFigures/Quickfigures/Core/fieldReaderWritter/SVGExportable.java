package fieldReaderWritter;

public interface SVGExportable {

	
	public SVGExporter getSVGEXporter();
}
