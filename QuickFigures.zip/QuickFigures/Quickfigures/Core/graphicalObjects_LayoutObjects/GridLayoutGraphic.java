package graphicalObjects_LayoutObjects;

public class GridLayoutGraphic extends PanelLayoutGraphic {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
