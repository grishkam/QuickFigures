package graphicalObjects;

import graphicalObjects_LayerTypes.GraphicLayer;

public interface KnowsParentLayer {
	public GraphicLayer getParentLayer() ;
	public void setParentLayer(GraphicLayer parent) ;
}
