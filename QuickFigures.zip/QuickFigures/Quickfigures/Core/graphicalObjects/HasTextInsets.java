package graphicalObjects;

import java.awt.Insets;

public interface HasTextInsets {
	public Insets getInsets();

	public void setInsets(Insets insetsPanelFromDialog);
}
