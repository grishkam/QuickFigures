package graphicalObjects;

public interface KnowsSetContainer {
	public void setGraphicSetContainer(GraphicSetDisplayContainer gc);
	public void updateDisplay();
}
