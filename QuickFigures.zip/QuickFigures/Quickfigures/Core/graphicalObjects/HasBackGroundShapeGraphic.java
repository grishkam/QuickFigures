package graphicalObjects;

import graphicalObjects_BasicShapes.ShapeGraphic;

public interface HasBackGroundShapeGraphic {
	public ShapeGraphic getBackGroundShape() ;
}
