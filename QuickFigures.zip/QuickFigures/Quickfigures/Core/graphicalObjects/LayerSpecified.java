package graphicalObjects;

public interface LayerSpecified {
	public Object getLayerKey();
	public void setLayerKey(Object o);
}
