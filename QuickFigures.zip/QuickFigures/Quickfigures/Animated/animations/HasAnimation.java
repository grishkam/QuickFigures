package animations;

public interface HasAnimation {
	public Animation getAnimation();
}
