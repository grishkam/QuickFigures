package animations;

public interface BasicKeyFrame {

	public int getFrame();
	public void setFrame(int t);
}
