package animations;

public interface KeyFrameCompatible extends HasAnimation {

	public  KeyFrameAnimation getOrCreateAnimation();
}
