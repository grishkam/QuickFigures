package menuUtil;

public interface HasUniquePopupMenu {
	public PopupMenuSupplier getMenuSupplier();
}
