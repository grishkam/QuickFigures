package menuUtil;

import java.awt.MenuItem;
import java.util.ArrayList;

public interface HasMenu {
	public ArrayList<MenuItem> getMenu();
}
