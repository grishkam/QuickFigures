package menuUtil;


import javax.swing.JPopupMenu;



public interface PopupMenuSupplier {
	JPopupMenu getJPopup();
}