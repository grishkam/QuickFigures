package selectedItemMenus;

import javax.swing.Icon;

import graphicalObjects_BasicShapes.TextGraphic;
import objectDialogs.TextInsetsDialog;

public class InsetOptionsSyncer extends BasicMultiSelectionOperator{

	@Override
	public String getMenuCommand() {
		// TODO Auto-generated method stub
		return "Set Insets";
	}
	

	@Override
	public void run() {
		TextInsetsDialog mt = new TextInsetsDialog(getAllArray(), true);
		mt.showDialog();

	}
	
	public Icon getIcon() {
		return TextGraphic.createImageIcon();
	}

}
