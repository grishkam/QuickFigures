package selectedItemMenus;

import javax.swing.Icon;

import graphicalObjects.ImagePanelGraphic;
import objectDialogs.MultiImageGraphicDialog;

public class ImageGraphicOptionsSyncer extends BasicMultiSelectionOperator {

	@Override
	public String getMenuCommand() {
		// TODO Auto-generated method stub
		return "Set Image Options";
	}


	@Override
	public void run() {
		MultiImageGraphicDialog mt = new MultiImageGraphicDialog(array);
		if (mt.getArray().size()==0) return;
		if (mt.getArray().size()==1) {
			mt.getArray().get(0).showOptionsDialog();
			//dialog.showDialog();
			return;
		}
		mt.showDialog();

	}

	public Icon getIcon() {
		return ImagePanelGraphic.createImageIcon();
	}
}