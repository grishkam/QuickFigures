package selectedItemMenus;

import javax.swing.Icon;

import graphicalObjects_BasicShapes.BarGraphic;
import objectDialogs.MultiBarDialog;

public class BarOptionsSyncer extends BasicMultiSelectionOperator {
	
	@Override
	public String getMenuCommand() {
		// TODO Auto-generated method stub
		return "Set Bar Options";
	}

	@Override
	public void run() {
		MultiBarDialog mt = new MultiBarDialog(array);
		mt.showDialog();

	}
	
	public Icon getIcon() {
		return BarGraphic.createImageIcon();
	}

}

