package selectedItemMenus;

import java.util.ArrayList;

import objectDialogs.MultiSnappingDialog;

public class SnappingSyncer extends BasicMultiSelectionOperator {


	
	@Override
	public String getMenuCommand() {
		return "Change relative positions";
	}



	@Override
	public void run() {
		
		createFromArray(array);
	

	}
	
	public static void createFromArray(ArrayList<?> array) {
		MultiSnappingDialog d = new MultiSnappingDialog(true);
		d.setGraphics(array);
		d.showDialog();
	}

}
