package selectedItemMenus;

import objectDialogs.ShapeGraphicOptionsSwingDialog;

public class ShapeOptionsSyncer extends BasicMultiSelectionOperator{

	@Override
	public String getMenuCommand() {
		return "Set Shape Options";
	}
	

	@Override
	public void run() {
		ShapeGraphicOptionsSwingDialog mt = new ShapeGraphicOptionsSwingDialog(getAllArray(), false);
		if (mt.hasItems())
			mt.showDialog();
	}

}
