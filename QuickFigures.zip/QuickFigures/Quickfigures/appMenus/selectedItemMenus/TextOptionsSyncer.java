package selectedItemMenus;

import javax.swing.Icon;

import graphicalObjects_BasicShapes.TextGraphic;
import objectDialogs.MultiTextGraphicSwingDialog;

public class TextOptionsSyncer extends BasicMultiSelectionOperator{

	@Override
	public String getMenuCommand() {
		return "Set Text Options";
	}
	

	@Override
	public void run() {
		MultiTextGraphicSwingDialog mt = new MultiTextGraphicSwingDialog(array, false);
		mt.showDialog();
	}
	
	public Icon getIcon() {
		return TextGraphic.createImageIcon();
	}

}
