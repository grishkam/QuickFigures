package basicMenusForApp;

import java.util.ArrayList;

import applicationAdapters.ImageWrapper;
import graphicActionToombar.CurrentSetInformerBasic;
import graphicalObjects.GraphicSetDisplayContainer;
import graphicalObjects.ZoomableGraphic;
import graphicalObjects_LayerTypes.GraphicLayer;
import layersGUI.LayerStructureChangeListener;
import selectedItemMenus.LayerSelector;
import utilityClasses1.ArraySorter;

/**A layer selector that returns the selected items in whatever set is the currently active one*/
public class CurrentSetLayerSelector  implements LayerSelector {

	@Override
	public GraphicLayer getSelectedLayer() {
		LayerStructureChangeListener<ZoomableGraphic, GraphicLayer> tree = getGraphicDisplayContainer().getGraphicLayerSet().getTree();
		if (tree!=null)
		return getGraphicDisplayContainer().getGraphicLayerSet().getTree().getSelectedLayer();
		return getGraphicDisplayContainer().getGraphicLayerSet();
	}

	@Override
	public ArrayList<ZoomableGraphic> getSelecteditems() {
		GraphicSetDisplayContainer contain = getGraphicDisplayContainer();
		if (contain==null) return new ArrayList<ZoomableGraphic>();
		ArrayList<ZoomableGraphic> all = contain.getGraphicLayerSet().getAllGraphics();
		ArraySorter.removeNonSelectionItems(all);
		return all;
	}

	@Override
	public GraphicSetDisplayContainer getGraphicDisplayContainer() {
		return new CurrentSetInformerBasic().getCurrentlyActiveOne();
	}

	@Override
	public ImageWrapper getImageWrapper() {
		return getGraphicDisplayContainer().getAsWrapper();
	}
	


}
