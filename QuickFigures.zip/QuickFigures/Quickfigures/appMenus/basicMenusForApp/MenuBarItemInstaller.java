package basicMenusForApp;

public interface MenuBarItemInstaller {
	
	/**called when a menu bar is created*/
	void addToMenuBar(MenuBarForApp installer);
	
}
