package addObjectMenus;

public interface AddingMenuInstaller {
	
	public void installOntoMenu(ObjectAddingMenu menu);

}
