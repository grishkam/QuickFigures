package popupMenusForComplexObjects;

import java.awt.event.ActionEvent;

import javax.swing.JMenu;

import channelMerging.MultiChannelSlotDialog;
import genericMontageKit.PanelList;
import graphicActionToombar.CurrentSetInformerBasic;
import graphicalObjects_FigureSpecific.MultichannelDisplayLayer;
import graphicalObjects_FigureSpecific.PanelGraphicInsetDef;
import logging.IssueLog;
import sUnsortedDialogs.ScaleResetListener;
import sUnsortedDialogs.ScaleSettingDialog;
import utilityClassesForObjects.ScaleInfo;
import applicationAdapters.HasScaleInfo;

public class ImageMenuForMultiChannel extends MenuForChannelLabelMultiChannel {

	public ImageMenuForMultiChannel(String name, MultichannelDisplayLayer panel,
			PanelList list) {
		super(name, panel, list, panel.getChannelLabelManager());
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public void generateLabelMenuItems() {
		createCropOption();
		createShowImageItem();
		
		
		createSetScaleItem() ;
		
		createColorImageItem();
	
		
		JMenu mm = new JMenu("Expert Options") ;
		createSaveImageItem(mm) ;
		createSetImageItem(mm) ;
		createMultiChanOpsions(mm) ;
		createChannelUseItem(mm);
		this.add(mm);
		
	}
	
	private menuItem createMultiChanOpsions(JMenu thi) {
		menuItem out=new menuItem("Saving Options  ") {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				MultiChannelSlotDialog dia = new MultiChannelSlotDialog(display.getSlot()) ;
				dia.showDialog();
			}
			
		};
		thi.add(out);
		return out;
		
		
	}
	
	private menuItem createSetScaleItem() {
		menuItem out=new menuItem("Set Pixel Size/Scale") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
			ScaleSettingDialog ssd = new  ScaleSettingDialog(display.getSlot(), null, true);
			ssd.setWindowCentered(true);
			ssd.setModal(true);
			ssd.setScaleResetListen(new ScaleResetListener() {

				@Override
				public void scaleReset(HasScaleInfo scaled, ScaleInfo info) {
					display.updateFromOriginal();
					display.updatePanels();
					
					for (PanelGraphicInsetDef i: display.getInsets()) {
						i.updateDisplayPanelImages();
					}
					
				new CurrentSetInformerBasic().updateDisplayCurrent();
					IssueLog.log("Expect to see scale bars resize");
				}
				
			});
			ssd.showDialog();
			}
			
		};
		this.add(out);
		return out;
		
	}

	
	
	menuItem createShowImageItem() {
		menuItem out=new menuItem("Show Image") {
			private static final long serialVersionUID = 1L;
			@Override
			public void actionPerformed(ActionEvent e) {
				display.getSlot().showImage();
			}
			
		};
		this.add(out);
		return out;
	}
	
	menuItem createCropOption() {
		menuItem out=new menuItem("Re-Crop") {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				FigureOrganizingSuplierForPopup.showRecropDisplayDialog(display, null);
			}
			
		};
		this.add(out);
		return out;
	}
	
	
	

	menuItem createColorImageItem() {
		menuItem out=new menuItem("Recolor Channels Automatically") {
			private static final long serialVersionUID = 1L;
			public void actionPerformed(ActionEvent e) {
				display.getSlot().getMultichanalWrapper().colorBasedOnRealChannelName();
				display.updatePanelsAndLabelsFromSource();
				display.updateDisplay();
			}
			
		};
		this.add(out);
		return out;
	}
	
	menuItem createSaveImageItem(JMenu thi) {
		menuItem out=new menuItem("Save Image") {
						private static final long serialVersionUID = 1L;
						public void actionPerformed(ActionEvent e) {
							display.getSlot().saveImageEmbed();
						}	};
		thi.add(out);
		return out;
	}
	
	menuItem createSetImageItem(JMenu thi) {
		menuItem out=new menuItem("Set Image") {
			private static final long serialVersionUID = 1L;
			public void actionPerformed(ActionEvent e) {
				display.getSlot().setImageDialog();
			}
		};
		thi.add(out);
		return out;
	}
	
	menuItem createChannelUseItem(JMenu thi) {
		menuItem out=new menuItem("Channel Use ") {
			private static final long serialVersionUID = 1L;
			@Override
			public void actionPerformed(ActionEvent e) {
				display. showStackOptionsDialog();
			}
		};
		thi.add(out);
		return out;
	}
}
