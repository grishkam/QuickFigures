package popupMenusForComplexObjects;

import javax.swing.JMenu;

public class MultiChannelImageMenu extends JMenu {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
