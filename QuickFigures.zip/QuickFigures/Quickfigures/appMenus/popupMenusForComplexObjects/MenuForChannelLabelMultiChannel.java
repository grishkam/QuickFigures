package popupMenusForComplexObjects;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

import channelLabels.ChannelLabelManager;
import genericMontageKit.PanelList;
import graphicalObjects_FigureSpecific.MultichannelDisplayLayer;

public class MenuForChannelLabelMultiChannel extends JMenu {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected MultichannelDisplayLayer display;
	protected PanelList stack;
	protected ChannelLabelManager man;
	
	

	public MenuForChannelLabelMultiChannel(String name, MultichannelDisplayLayer  panel, PanelList list, ChannelLabelManager man) {
		this.setText(name);
		this.setName(name);
		display=panel;
		stack=list;
		this.man=man;
		generateLabelMenuItems();
	}
	
	public void generateLabelMenuItems() {
		createMergeMenuItem() ;
		createNameChannelLabelItem();
		createAllLabelMenuItem();
		JMenu add=new JMenu("Add");
		JMenu rem=new JMenu("Remove");
		create1ChannelLabelItem(add);
		create1MergeLabelItem(add) ;
		createGenerateChannelLabelItem(add);
		createGenerateChannelLabelItem2(add);
		this.add(add);
		createEliminateChannelLabelItem(rem) ;
		this.add(rem);
		
		//createCopySavedChannelLabelItem();
		JMenu expert = new JMenu("Expert Options");
		createResetNameItem(expert);
		this.add(expert);
	}
	
	public menuItem createAllLabelMenuItem() {
		menuItem out=new menuItem("Edit All Channel Labels") {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				man.completeMenu();
			}
			
		};
		this.add(out);
		return out;
	}
	
	
	
	menuItem createMergeMenuItem() {
		menuItem out=new menuItem("Merge Label Menu") {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				
				man.showChannelLabelPropDialog();
				
			}
			
		};
		this.add(out);
		return out;
	}
	
	menuItem create1MergeLabelItem(JMenu thi) {
		menuItem out=new menuItem("Add 1 Merge Label") {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				man.addSingleMergeLabel();
				
			}
			
		};
		thi.add(out);
		return out;
	}
	
	menuItem create1ChannelLabelItem(JMenu thi) {
		menuItem out=new menuItem("Add 1 Channel Label") {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				man.addSingleChannelLabel();
			}
			
		};
		thi.add(out);
		return out;
	}
	
	menuItem createEliminateChannelLabelItem(JMenu j) {
		menuItem out=new menuItem("Eliminate Channel Labels") {
			private static final long serialVersionUID = 1L;
			@Override
			public void actionPerformed(ActionEvent e) {
				man.eliminateChanLabels();
			}
		};
		j.add(out);
		return out;
	}
	
	menuItem createCopySavedChannelLabelItem() {
		menuItem out=new menuItem("Load Label Properties From Saved") {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				display.setLabalPropertiesToSaved();
			}
			
		};
		this.add(out);
		return out;
	}
	
	menuItem createGenerateChannelLabelItem(JMenu thi) {
		menuItem out=new menuItem("Generate New Channel Labels") {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				man.generateChannelLabels();
			}
			
		};
		thi.add(out);
		return out;
	}
	
	menuItem createGenerateChannelLabelItem2(JMenu thi) {
		menuItem out=new menuItem("Generate New Channel Labels (first slice only)") {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				man.generateChannelLabels2();
			}
			
		};
		thi.add(out);
		return out;
	}
	
	menuItem createNameChannelLabelItem() {
		menuItem out=new menuItem("Set Channel Labels") {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				man.nameChannels();
			}
			
		};
		this.add(out);
		return out;
	}
	
	menuItem createResetNameItem(JMenu thi) {
		menuItem out=new menuItem("Reset Channel Names") {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				display.getMultichanalWrapper().renameBasedOnRealChannelName();;
				display.updatePanelsAndLabelsFromSource();
			}
			
		};
		thi.add(out);
		return out;
	}
	

	 protected abstract class menuItem extends JMenuItem implements ActionListener {
		 
		 /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public menuItem(String name) {
			 super(name);
			 this.addActionListener(this);
			 
		 }
		 
		 
		
		 
	 }

}
