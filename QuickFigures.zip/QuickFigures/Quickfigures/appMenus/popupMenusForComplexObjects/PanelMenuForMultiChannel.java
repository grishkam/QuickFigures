package popupMenusForComplexObjects;

import java.awt.event.ActionEvent;

import javax.swing.JMenu;

import fLexibleUIKit.ObjectAction;
import genericMontageKit.PanelList;
import genericMontageKit.PanelListElement;
import graphicalObjects.ImagePanelGraphic;
import graphicalObjects_FigureSpecific.MultichannelDisplayLayer;
import graphicalObjects_FigureSpecific.PanelManager;
import objectDialogs.PanelStackDisplayOptions;
import panelGUI.PanelListDisplayGUI;
import standardDialog.StandardDialog;

public class PanelMenuForMultiChannel extends MenuForChannelLabelMultiChannel {

	
	private PanelManager panelManager;

	public PanelMenuForMultiChannel(String name, MultichannelDisplayLayer panel,
			PanelList list, PanelManager panMan) {
		super(name, panel, list,  panel.getChannelLabelManager());
		panelManager=panMan;
		if(panMan==null) {panMan=panel.getPanelManager();}
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void generateLabelMenuItems() {
		
		recreateChannelUseMenuItem();
		showPanelListItem() ;
		create1ChannelPanelMenuItem();
		addChangePPIMenuItem();
		
		
		JMenu expert=new JMenu("Expert Options");
		createImagePanelMenuItem(expert);
		createEliminatePanelMenuItem(expert) ;
	//	create1MergePanelMenuItem();
		recreatePanelsMenuItem(expert);
		this.add(expert);
		
		
	}

	public void addChangePPIMenuItem() {
		add(new ObjectAction<PanelManager>(panelManager) {
			@Override
			public void actionPerformed(ActionEvent e) {
				ImagePanelGraphic panel = panelManager.getStack().getPanels().get(0).getPanelGraphic();
			double ppi = panel.getQuickfiguresPPI();
			double newppi=StandardDialog.getNumberFromUser("Input PPI ", ppi);
			panelManager.changePPI(newppi);
			}
			
		}.createJMenuItem("Change Panel PPI (Scale if needed)"));
	}
	
	menuItem createImagePanelMenuItem(JMenu  thi) {
		menuItem out=new menuItem("Generate New Image Panels") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				stack.addAllCandF(display.getMultichanalWrapper());
				panelManager.generatePanelGraphicsFor(stack);
			}
			
		};
		thi.add(out);
		return out;
	}
	
	menuItem createEliminatePanelMenuItem(JMenu thi) {
		menuItem out=new menuItem("Eliminate Image Panels") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				panelManager.eliminatePanels(stack);
				panelManager.updateDisplay();
			}
			
		};
		thi.add(out);
		return out;
	}
	
	
	menuItem create1MergePanelMenuItem() {
		menuItem out=new menuItem("Create 1 Merge Panel") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				panelManager.addSingleMergePanel(stack);
				panelManager.updateDisplay();
			}
			
		};
		this.add(out);
		return out;
	}
	
	menuItem create1ChannelPanelMenuItem() {
		menuItem out=new menuItem("Create Extta Panel") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				PanelListElement panelp = panelManager.addSingleChannelPanel(stack);
				panelManager.putSingleElementOntoGrid(panelp, true);
				panelManager.updateDisplay();
			}
			
		};
		this.add(out);
		return out;
	}
	
	
	menuItem recreateChannelUseMenuItem() {
		menuItem out=new menuItem("Channel Use") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				new PanelStackDisplayOptions(display, stack, panelManager,false).showDialog();;
				
			}
			
		};
		this.add(out);
		return out;
	}
	
	menuItem recreatePanelsMenuItem(JMenu j) {
		menuItem out=new menuItem("Separately Recreate Panels") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				display.showOptionsThenRegeneratePanelGraphics();
			}
			
		};
		j.add(out);
		return out;
	}
	
	menuItem showPanelListItem() {
		menuItem out=new menuItem("Advanced Channel Use") {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				PanelListDisplayGUI distpla = new PanelListDisplayGUI( panelManager, man);
				
				distpla.setVisible(true);
			}
			
		};
		this.add(out);
		return out;
	}
	
}
