package fLexibleUIKit;

import java.awt.event.ActionListener;
import java.lang.reflect.Method;

import javax.swing.JMenuItem;

public abstract class ObjectAction<Type> implements ActionListener {
	
	public Type item;
	Method m;
	
	public ObjectAction(Type i) {
		item=i;
	}
	
	public ObjectAction(Type i, Method m) {
		item=i;
		this.m=m;
	}

	public JMenuItem createJMenuItem(String st) {
		JMenuItem out=new JMenuItem(st);
		out.addActionListener(this);
		return out;
	}
	
	

}
